package com.projectmanagement.dto;

import lombok.Data;

@Data
public class UpdateProjectRequestDto {
	
	private int projectId;
	
	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public int getTeamleadId() {
		return teamleadId;
	}

	public void setTeamleadId(int teamleadId) {
		this.teamleadId = teamleadId;
	}

	public int getTeammemberId() {
		return teammemberId;
	}

	public void setTeammemberId(int teammemberId) {
		this.teammemberId = teammemberId;
	}

	public String getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}

	private int teamleadId;
	
	private int teammemberId;
	
	private String projectStatus;

}
