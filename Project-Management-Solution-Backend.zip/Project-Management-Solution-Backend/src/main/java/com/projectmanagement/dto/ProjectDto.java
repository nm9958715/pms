package com.projectmanagement.dto;

import lombok.Data;

@Data
public class ProjectDto {
	
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAssignedToTeamlead() {
		return assignedToTeamlead;
	}

	public void setAssignedToTeamlead(String assignedToTeamlead) {
		this.assignedToTeamlead = assignedToTeamlead;
	}

	public String getAssignedToTeammember() {
		return assignedToTeammember;
	}

	public void setAssignedToTeammember(String assignedToTeammember) {
		this.assignedToTeammember = assignedToTeammember;
	}

	public String getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}

	public int getTeammemberId() {
		return teammemberId;
	}

	public void setTeammemberId(int teammemberId) {
		this.teammemberId = teammemberId;
	}

	public int getTeamleadId() {
		return teamleadId;
	}

	public void setTeamleadId(int teamleadId) {
		this.teamleadId = teamleadId;
	}

	public String getTeamleadName() {
		return teamleadName;
	}

	public void setTeamleadName(String teamleadName) {
		this.teamleadName = teamleadName;
	}

	public String getTeammemberName() {
		return teammemberName;
	}

	public void setTeammemberName(String teammemberName) {
		this.teammemberName = teammemberName;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(String assignedDate) {
		this.assignedDate = assignedDate;
	}

	public String getDeadlineDate() {
		return deadlineDate;
	}

	public void setDeadlineDate(String deadlineDate) {
		this.deadlineDate = deadlineDate;
	}

	private String name;
	
	private String description;
	
	private String assignedToTeamlead;
	
	private String assignedToTeammember;
	
	private String projectStatus;
	
    private int teammemberId;
	
	private int teamleadId;
	
	private String teamleadName;
	
	private String teammemberName;
	
	private String requirement;
	
	private String createdDate;
	
	private String assignedDate;
	
	private String deadlineDate;

}
